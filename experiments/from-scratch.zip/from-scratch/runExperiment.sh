node updateTexts.js
meteor
