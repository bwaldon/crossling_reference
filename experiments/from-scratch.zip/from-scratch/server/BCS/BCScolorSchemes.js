// constant that contains colors
export const cs1Dict = ['blue', 'red', 'yellow', 'white'];
export const cs2Dict = ['purple', 'orange', 'green', 'black'];
